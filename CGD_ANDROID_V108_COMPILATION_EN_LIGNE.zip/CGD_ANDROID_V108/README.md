# CGD Android — V108

Projet Android Studio qui embarque le moteur HTML CGD V108 dans une WebView locale.

## Configuration
- Application : CGD
- Identifiant : `com.cgd.game`
- Version : `1.0.8` (versionCode 108)
- Orientation : paysage
- Minimum : Android 6.0 (API 23)
- Compilation : Android SDK 35, Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17
- Jeu embarqué : `app/src/main/assets/index.html`
- Fonctionnement prévu hors connexion ; aucun accès Internet n'est déclaré.

## Compiler l'APK
1. Installer Android Studio et le SDK Android 35.
2. Ouvrir le dossier `CGD_ANDROID_V108` dans Android Studio.
3. Laisser Gradle synchroniser le projet (JDK 17).
4. Pour un APK de test : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Pour une version distribuable : **Build > Generate Signed Bundle / APK > APK**, puis créer/conserver une clé de signature privée.

L'APK de test se trouve normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

## Contrôles indispensables sur téléphone
- Lancement et affichage paysage ;
- rendu 3D/WebGL et fluidité ;
- coups, prises multiples, dames et effets ;
- sauvegarde puis fermeture/réouverture ;
- reprise après rotation ou interruption ;
- comportement sur un appareil Android d'entrée de gamme.

## Limites connues
Ce projet est une première enveloppe Android autour du jeu existant. Il ne constitue pas une validation complète du gameplay ni un test sur appareil réel. La création de l'APK nécessite Android Studio/SDK ; l'environnement de préparation utilisé pour générer ce dossier ne contient pas le SDK Android/Gradle.
