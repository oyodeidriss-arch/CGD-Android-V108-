# Compiler CGD V108 depuis un téléphone Android (sans Android Studio)

Cette méthode utilise GitHub Actions. La compilation se fait sur les serveurs GitHub. Le téléphone sert à créer le dépôt, téléverser l'archive et récupérer l'APK.

## 1. Créer un dépôt privé
1. Ouvrir https://github.com dans le navigateur du téléphone et se connecter.
2. Créer un nouveau dépôt nommé `CGD-Android-V108`.
3. Choisir **Private**.
4. Créer le dépôt.

## 2. Ajouter le fichier de compilation
Dans le dépôt GitHub :
1. Choisir **Add file > Create new file**.
2. Nom exact du fichier : `.github/workflows/android-apk.yml`.
3. Coller le contenu YAML fourni dans le message ChatGPT qui accompagne cette archive.
4. Valider avec **Commit changes**.

## 3. Téléverser l'archive
1. Depuis le téléphone, téléverser le fichier `CGD_ANDROID_V108_COMPILATION_EN_LIGNE.zip` à la racine du dépôt avec **Add file > Upload files**.
2. Valider avec **Commit changes**.

Le workflow GitHub décompresse cette archive puis compile le projet Android. Il ne faut pas téléverser l'archive dans un autre dossier.

## 4. Récupérer l'APK
1. Ouvrir l'onglet **Actions** du dépôt.
2. Sélectionner **Build CGD Android APK**.
3. Attendre la fin de l'exécution et la coche verte.
4. Ouvrir l'exécution puis télécharger l'élément **CGD-V108-APK-debug** dans la section **Artifacts**.
5. Extraire l'archive téléchargée et installer `app-debug.apk` sur le téléphone.

## Important
- L'APK produit est une version **debug** destinée aux essais, pas une version signée pour publication.
- La compilation n'est pas encore exécutée : l'APK n'existe qu'après une exécution GitHub réussie.
- Tester le rendu 3D/WebGL, les règles de jeu, les sauvegardes et la fluidité sur le téléphone.
